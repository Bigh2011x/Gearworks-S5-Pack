---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Crystal Fixer
    icon: expatternprovider:crystal_fixer
categories:
- extended devices
item_ids:
- expatternprovider:crystal_fixer
---

# ME Crystal Fixer

<BlockImage id="expatternprovider:crystal_fixer" scale="8"></BlockImage>

ME Crystal Fixer can repair budding certus block and turn it to the upgraded one.

It needs <ItemLink id="ae2:charged_certus_quartz_crystal" /> and power to work. Right-click it with <ItemLink id="ae2:charged_certus_quartz_crystal" /> to input.

<Row gap="20">
<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/crystal_fixer.snbt"></ImportStructure>
</GameScene>
</Row>
