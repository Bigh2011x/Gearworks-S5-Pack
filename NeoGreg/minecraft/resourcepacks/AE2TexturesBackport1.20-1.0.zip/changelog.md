# Changelog
All notable changes to this project will be documented in this file.
## [1.20+1.0] - 2025.5.23
### Added
- Added changelog.md file in resourcepack
- Added NOTICE file in resourcepack
- Added the AE2 guides
- Added the localization files
- Added Fullblock Engistics support
### Changed
- Changed pack description
- Changed wireless terminals GUI
- Changed pattern mode GUI
- Changed icon textures
- Changed buttons and scrollers
### Fixed
- Fixed some GUI doesn't work well
### Updated
- Updated import export bus textures
- Updated mana cell disk textures
- Updated mega fe cells textures
- Updated sky harden instlating resin texture
- Updated creative chemical cell texture
- Updated mana p2p tunnel texture
- Updated ex emc interface block and part textures
- Updated ex emc import and export bus textures
- Updated emc interface and io bus upgrade items textures
- Updated mega cells textures and models
### Removed
- Removed useless textures and models